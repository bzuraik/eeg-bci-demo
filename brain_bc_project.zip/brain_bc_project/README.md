# EEG Brain‑Computer Interface Proof‑of‑Concept

This repository contains a small end‑to‑end demonstration of how
electroencephalography (EEG) signals can be translated into digital
commands. The goal of this proof‑of‑concept is to show, in a clear and
reproducible manner, how to load raw EEG data, train a classifier to
distinguish brain states and use the classifier’s output to drive a
simple interactive interface.

## Dataset

The project uses the **EEG Eye State** dataset collected with an
Emotiv Neuroheadset. According to the data description, a single
volunteer wore the headset for 117 seconds while their eye state was
recorded by a camera; the EEG was sampled on 14 channels (AF3, F7, F3,
FC5, T7, P7, O1, O2, P8, T8, FC6, F4, F8 and AF4). The target value
`eyeDetection` is `0` when the eyes are open and `1` when they are
closed【461530564295294†L4-L19】.  The raw dataset contains 14 980 time
samples and no missing values【300254446879847†L45-L50】.

Because downloading directly from the UCI repository is problematic in
this environment, the `data/` folder contains a copy of the CSV file
(`eeg_eye_state_full.csv`) that you can use for training and
experimentation. Each row in this file corresponds to one time step,
with 14 numeric features followed by the binary label.

## Project structure

```
brain_bc_project/
├── data/                 # EEG dataset (CSV)
├── docs/                 # Documentation assets (empty in this demo)
├── models/               # Saved trained models (.pth)
├── src/
│   ├── data_utils.py     # Data loading and preprocessing utilities
│   ├── model.py          # Neural network definition and save/load helpers
│   ├── train.py          # Script to train the classifier
│   └── demo.py           # Pygame application demonstrating action mapping
└── README.md             # This file
```

## Installation

Install the required Python packages into a virtual environment. You
can use `pip` to install dependencies as follows:

```bash
python -m venv venv
source venv/bin/activate
pip install torch torchvision torchaudio
pip install pandas scikit‑learn pygame
```

Note: depending on your system, you might need to install additional
system dependencies for **Pygame** (e.g. `libsdl2-dev`) before
installing via `pip`.

## Training the model

1. **Prepare the data:** Ensure `data/eeg_eye_state_full.csv` is present. The
   14 numeric feature columns will be normalised (z‑score) during
   training by default.
2. **Run the training script:**

   ```bash
   python src/train.py \
       --data data/eeg_eye_state_full.csv \
       --output models/eeg_classifier.pth \
       --epochs 20 \
       --batch_size 64 \
       --hidden_size 64 \
       --learning_rate 0.001
   ```

   The script prints the training and test accuracy for each epoch and
   saves the final model (including the normalisation scaler) to the
   specified path. With the default settings the network typically
   achieves > 95 % accuracy on the held‑out test set.

## Running the demo

After training, launch the interactive demo to see how the classifier’s
predictions can control a simple graphical object. The demo loads the
model, streams samples from the EEG dataset and maps the predicted
classes to movements:

* **Class 0 – eyes open:** moves the square **right**.
* **Class 1 – eyes closed:** moves the square **left**.

```bash
python src/demo.py \
    --model models/eeg_classifier.pth \
    --data data/eeg_eye_state_full.csv \
    --speed 20
```

The `--speed` parameter controls how many samples per second are
processed; lower values slow down the motion, allowing you to watch the
square move left and right as the model classifies the incoming EEG
signal. Close the window or press the **Esc** key to exit.

## Real‑world applications

Although this project uses pre‑recorded data and a simple mapping
between eye state and cursor movement, the same principles apply to
more sophisticated brain‑computer interfaces. Modern systems like
Neuralink or OpenBCI use invasive or high‑density EEG recordings to
decode complex motor imagery or speech intentions. Potential
applications include assistive technologies for people with motor
impairments, game control using thought patterns, and even hands‑free
interaction with augmented/virtual reality systems.

This proof‑of‑concept offers a starting point for exploring such
interfaces: by swapping in a different dataset (e.g. motor imagery
signals【227508551410058†L78-L137】) and adjusting the mapping logic, you could move a
cursor up/down/left/right or trigger actions based on more subtle brain
states. The modular design of the code makes it straightforward to
experiment with alternative architectures, training strategies or
interaction modalities.